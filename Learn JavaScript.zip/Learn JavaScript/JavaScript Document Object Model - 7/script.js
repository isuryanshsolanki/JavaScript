console.log("Hey this is JavaScript");



document.title = "JavaScript Document Object Model";
console.log(document.title);
console.log(document.body);

document.body.style.backgroundColor = "green";