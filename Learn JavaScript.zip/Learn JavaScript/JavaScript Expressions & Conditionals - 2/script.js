console.log("Hey this is JavaScript");

let a = 3;
let b = 2;

console.log(a + b);
console.log(a - b);
console.log(a * b);
console.log(a ** b);
console.log(a / b);
console.log(a % b);
console.log(a++);
console.log(b--);


a += b;
console.log(a);

a = a + b;
console.log(a);


let num = 10;
let num2 = 10;

console.log(num == num2);
console.log(num != num2);
console.log(num === num2);
console.log(num !== num2);
console.log(num > num2);
console.log(num < num2);
console.log(num >= num2);
console.log(num <= num2);
let output = num ? "yes" : "no";
console.log(output);
console.log(!true);


let ab = 5;
let bc = 10;
console.log(ab != bc);
console.log(ab == bc);

console.log(ab != bc && bc != ab);
console.log(ab != bc && bc == ab);

console.log(ab != bc || bc != ab);
console.log(ab != bc || bc == ab);



let age = 13;
let grace = 5;
console.log(age + grace);


if ((age + grace) >= 18) {
    console.log("You Can Drive A Car");
}


if ((age + grace) >= 18) {
    console.log("You Can Drive A Car");
} else {
    console.log("You Cannot Drive A Car");
}


if (age >= 18) {
    console.log("You Can Drive A Car");
} else if (age == 13) {
    console.log("You Are Only 13");
} else {
    console.log("You Cannot Drive A Car");
}



let a1 = 6;
let a2 = 8;
let a3 = a1>a2 ?(a1-a2): (a2 - a1);
console.log(a3);