console.log("Hey thi is JavaScript");

let a = 1;

for (let index = 0; index < 100; index++) {
    console.log(a + index);
}



let obj = {
    "Name": "Suryansh Solanki",
    "Role": "Founder & CEO",
    "Company": "None"
}

for (const key in obj) {
    const element = obj[key];
    console.log(key, element);
}



for (const element of "Suryansh") {
    console.log(element);
}



let b = 10;

while (b<20) {
    console.log(b);
    b++;
}



let c = 10;

do {
    console.log(c);
    c++;
} while (c<20);