console.log("Hey this is JavaScipt");



let randomnum = Math.random();
console.log(randomnum);

let randomnum2 = (Math.floor(Math.random() * 5) + 1);
console.log(randomnum2);

const max = 100;
const min = 50;

let randomnum3 = (Math.floor(Math.random() * max) + min);
console.log(randomnum3);
