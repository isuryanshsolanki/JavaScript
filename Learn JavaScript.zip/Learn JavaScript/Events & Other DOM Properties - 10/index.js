console.log("Hey this is JavaScript");



document.querySelector(".remove").remove();



let containers = document.querySelector(".container1");

console.log(containers.classList);
console.log(containers.className);

console.log(containers.classList.toggle("contanier4"));
console.log(containers.classList.toggle("contanier4"));

console.log(containers.classList.add("container5"));
console.log(containers.classList.remove("container5"));




document.designMode ="on";
document.designMode ="off";