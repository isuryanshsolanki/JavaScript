console.log("Hey this is JavaScript");



let button = document.getElementById("button");

button.addEventListener("click", ()=>{
    document.querySelector(".click").innerHTML = "You Clicked On A Button"
});

button.addEventListener("dblclick", ()=>{
    document.querySelector(".click").innerHTML = "You Double Clicked On A Button"
});

button.addEventListener("contextmenu", ()=>{
    document.querySelector(".click").innerHTML = "You Clicked Right Side Of Mouse On A Button"
});

// We Can Also Use It Something Like That...

// button.onclick = () => {
//     document.querySelector(".click").innerHTML = "You Clicked On A Button"
// }

// button.ondblclick = ()=>{
//     document.querySelector(".click").innerHTML = "You Double Clicked On A Button"
// }

// button.oncontextmenu = ()=>{
//     document.querySelector(".click").innerHTML = "You Clicked Right Side Of Mouse On A Button"
// }


document.addEventListener("keydown", (e)=>{
    console.log(e, e.key, e.keyCode);
});