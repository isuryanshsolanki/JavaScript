console.log("Hey this is JavaScript");



let e = document.body;

console.log(e);
console.dir(e);


console.log(document.querySelector(".box"));
console.log(document.querySelector(".box").innerHTML);
console.log(document.querySelector(".container").innerHTML);
console.log(document.querySelector("body").innerHTML);


console.log(document.querySelector(".box").innerText);
console.log(document.querySelector(".container").innerText);
console.log(document.querySelector("body").innerText);


console.log(document.querySelector(".box").outerHTML);
console.log(document.querySelector(".container").outerHTML);
console.log(document.querySelector("body").outerHTML);


console.log(document.querySelector(".box").tagName);
console.log(document.querySelector(".container").tagName);
console.log(document.querySelector("body").tagName);


console.log(document.querySelector(".box").nodeName);
console.log(document.querySelector(".container").nodeName);
console.log(document.querySelector("body").nodeName);


console.log(document.querySelector(".box").tagName);
console.log(document.querySelector(".container").textContent);
console.log(document.querySelector("body").textContent);


console.log(document.querySelector(".box").hidden);
console.log(document.querySelector(".container").hidden);
console.log(document.querySelector("body").hidden);

console.log(document.querySelector(".box").hidden = true);
console.log(document.querySelector(".container").hidden = true);
console.log(document.querySelector("body").hidden = true);

console.log(document.querySelector(".box").hidden = false);
console.log(document.querySelector(".container").hidden = false);
console.log(document.querySelector("body").hidden = false);



console.log(document.querySelector(".box").innerHTML = "Box");


console.log(document.querySelector(".box").hasAttribute("class"));
console.log(document.querySelector(".container").hasAttribute("class"));
console.log(document.querySelector("body").hasAttribute("class"));

console.log(document.querySelector(".box").getAttribute("class"));
console.log(document.querySelector(".container").getAttribute("class"));
console.log(document.querySelector("body").getAttribute("class"));

console.log(document.querySelector(".box").setAttribute("id", "box"));
console.log(document.querySelector(".container").setAttribute("id", "container"));
console.log(document.querySelector("body").setAttribute("id", ""));

console.log(document.querySelector(".box").attributes);
console.log(document.querySelector(".container").attributes);
console.log(document.querySelector("body").attributes);

console.log(document.querySelector(".box").removeAttribute("id"));
console.log(document.querySelector(".container").removeAttribute("id"));
console.log(document.querySelector("body").removeAttribute("id"));


console.log(document.querySelector(".box").dataset);



let div = document.createElement("div");
div.innerHTML = "Box"
div.setAttribute("class", "box");
document.querySelector(".container").append(div);

let div2 = document.createElement("div");
div2.innerHTML = "Box"
div2.setAttribute("class", "box");
document.querySelector(".container").prepend(div2);

let div3 = document.createElement("div");
div3.innerHTML = "Box"
div3.setAttribute("class", "box");
document.querySelector(".container").after(div3);

let div4 = document.createElement("div");
div4.innerHTML = "Box"
div4.setAttribute("class", "box");
document.querySelector(".container").before(div4);

let div5 = document.createElement("div");
div5.innerHTML = "Box"
div5.setAttribute("class", "box");
document.querySelector(".container").before(div5);


let div6 = document.querySelector("#replace");
div6.replaceWith("Box");



let cont = document.querySelector("#container");

cont.insertAdjacentHTML("afterbegin", `<div class ="box">Box</div>`);

cont.insertAdjacentHTML("afterend", `<div class ="box">Box</div>`);

cont.insertAdjacentHTML("beforebegin", `<div class ="box">Box</div>`);

cont.insertAdjacentHTML("beforeend", `<div class ="box">Box</div>`);