console.log("Hey this is JavaScript");


console.log(document.body);
console.log(document.body.childNodes);
console.log(document.body.childNodes[0]);
console.log(document.body.childNodes[1]);
console.log(document.body.childNodes[1].childNodes);



let cont = document.body.childNodes[1];

console.log(cont.firstChild);
console.log(cont.lastChild);
console.log(cont.firstElementChild);
console.log(cont.lastElementChild);

console.log(cont.firstElementChild.style.color = "red");
console.log(cont.lastElementChild.style.color = "red");
console.log(cont.firstElementChild.style.backgroundColor = "blue");
console.log(cont.lastElementChild.style.backgroundColor = "blue");

console.log(cont.firstElementChild.parentElement);
console.log(cont.lastElementChild.parentElement);



console.log(document.body.firstElementChild.children);
console.log(document.body.lastElementChild.children);

console.log(document.body.firstElementChild.children[3]);

console.log(document.body.firstElementChild.children[3].nextElementSibling);
console.log(document.body.firstElementChild.children[3].previousElementSibling);



console.log(document.body.children);
console.log(document.body.children[1]);
console.log(document.body.children[1].rows);
console.log(document.body.children[1].caption);
console.log(document.body.children[1].thead);
console.log(document.body.children[1].tfoot);
console.log(document.body.children[1].tBodies);



console.log(document.getElementById("container"));
console.log(document.getElementsByClassName("container"));

console.log(document.querySelectorAll(".container"));
console.log(document.querySelector(".box"));

console.log(document.getElementsByTagName("div"));
console.log(document.getElementsByTagName("div")[0]);

console.log(getElementsByName("container"));