console.log("hey this is JavaScript");



let e = document.getElementsByTagName("span");

console.log(e[4].matches("#text4"));
console.log(e[3].matches("#text4"));


console.log(e[3].closest("#text4"));
console.log(e[3].closest("#container"));
console.log(e[3].closest("html"));

console.log(document.querySelector("#text1").contains(e[1]));
console.log(document.querySelector("#text1").contains(e[2]));

