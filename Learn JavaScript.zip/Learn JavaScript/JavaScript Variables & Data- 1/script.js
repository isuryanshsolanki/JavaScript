console.log("Hey this is JavaScript");

let a = 4;
a = a + 1;

let b = 6;
let c = "Suryansh";
let _a = "Suyash";
// let 0a = "Harsh"; // Not Allowed
let a0 = "Harsh";

// console.log(a + b + 8);
// console.log(typeof a, typeof b, typeof c);
{
    let a = 50;
    console.log(a);
}
console.log(a);
// const a1 = 4;
// a1 = a1 + 1;
// console.log(a1); // Not Allowed



let x = "Suryansh";
let y = 10;
let z = 10.5;
const p = true;
let q = undefined;
let r = null;
let n = 123456789012345678901234567890n;

console.log(x, y, z, p, q, r, n);
console.log(typeof x, typeof y, typeof z, typeof p, typeof q, typeof r, typeof n);



let obj = {
    "Name": "Suryansh Solanki",
    "Role": "Founder"
}

console.log(obj);
console.log(typeof obj);



obj.Salary = "100M";
obj["Born in"] = "2010 - 11 - 10"

console.log(obj);
console.log(typeof obj);



obj.Salary = "1B";
obj["Born in"] = "2010 - 11 - 10"

console.log(obj);
console.log(typeof obj);