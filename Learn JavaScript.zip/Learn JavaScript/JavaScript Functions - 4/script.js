console.log("Hey this is JavaScript");



function Enter(Name) {
    console.log("Hey " + Name + " You Are Nice!");
    console.log("Hey " + Name + " You Are Good!");
    console.log("Hey " + Name + " You Are A Coder!");
    console.log("Hey " + Name + " Im Also Good To!");
}

Enter("Suryansh");
Enter("Suyash");



function Numbers(a, b, c = 5) {
    console.log(a + b + c);
    return a + b + c;
}

let Result1 = Numbers(5, 10);
let Result2 = Numbers(10, 20);
let Result3 = Numbers(10, 10, 20);


console.log(`The a + b Result 1 is ${Result1}, Result 2 ${Result2} And Result 3 ${Result3}`);

console.log(`The a + b Result 1 is ${Result1}`);
console.log(`The a + b Result 2 is ${Result2}`);
console.log(`The a + b Result 3 is ${Result3}`);



const Fun = (Num) => {
    console.log(`Im An Arrow Function ${Num}`);
}

Fun(10);
Fun(20);
Fun(30);