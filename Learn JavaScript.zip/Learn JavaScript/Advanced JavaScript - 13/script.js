console.log("Hey this is JavaScript");



// async function sleep() {
//     return new Promise((resolve, reject) => {
//         setTimeout(() => {
//             resolve(100);
//         }, 1000);
//     })
// }

// let a = await sleep();
// let b = await sleep();
// console.log(a);
// console.log(b);

// We Can't Use This Here How To Use This...

async function sleep() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve(100);
        }, 1000);
    })
}

(async function main() {
    let a = await sleep();
    let b = await sleep();
    console.log(a);
    console.log(b);
})();



let [x, y, ...rest] = [0, 5, 10, 15, 20];
console.log(x, y, rest);


let obj = {
    "a": 1,
    "b": 2,
    "c": 3
}

let { a, b } = obj;
console.log(a, b);



function sum(a, b, c) {
    return a + b + c;
}

let arr = [1, 2, 3];
// Both Are Same Output...
console.log(sum(arr[0], arr[1], arr[2]));
console.log(sum(...arr));



// Only In Var...

console.log(v);
var v = 100;


// We Can Also Use Function Like This...

Fun();
function Fun() {
    console.log("Hey Im In Function...")
}