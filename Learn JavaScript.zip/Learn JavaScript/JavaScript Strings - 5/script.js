console.log("Hey this is JavaScript");



let a = "Suryansh";
console.log(a[0]);
console.log(a[1]);
console.log(a[2]);
console.log(a[3]);
console.log(a[4]);
console.log(a[5]);
console.log(a[6]);
console.log(a[7]);


console.log(a.length);



let Name = "Suryansh";
let Friend = "Sahil";
console.log("His Name Is " + Name + " And His Friend Name is " + Friend);
console.log(`His Name Is ${Name} And His Friend Name is ${Friend}`);



let b = "Suryansh' Is A Coder";
console.log(b);

let c = "Suryansh, Is A Coder";
console.log(c);

let d = `Suryansh" Is A Coder`;
console.log(d);

let e = "Suryansh\" Is A Coder";
console.log(e);

let f = "Suryansh\ Is A Coder";
console.log(f);




let Name2 = "Suyash";
console.log(Name2.toUpperCase());
console.log(Name2.toLowerCase());
console.log(Name2.length);
console.log(Name2.slice(0, 7));
console.log(Name2.slice(0));
console.log(Name2.charAt(0));
console.log(Name2.replace("yash", "ryansh"));
console.log(Name2.concat(a, "Harry"));
console.log(Name2.trim());
console.log(Name2.indexOf("yash"));
console.log(Name2.startsWith("Su"));
console.log(Name2.endsWith("sh"));


console.log(Name2);