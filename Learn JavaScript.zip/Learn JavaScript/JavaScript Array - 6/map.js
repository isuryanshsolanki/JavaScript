console.log("Hey this is JavaScript");



let arr = [1, 2, 3, 4, 5];

console.log(arr);

let newarr = arr.map((e, index, array) => {
    return e ** 2;
})

console.log(newarr);




let arr2 = [1, 2, 3, 4, 5];

let newarr2 = [];

for (let index = 0; index < arr2.length; index++) {
    const element = arr2[index];
    newarr2.push(element ** 2)
}

console.log(newarr2);



let arr3 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

console.log(arr3);

const greaterthan5 = (e) => {
    if (e > 5) {
        return true;
    } else {
        return false;
    }
}

console.log(arr3.filter(greaterthan5));



let arr4 = [1,2,3,4,5];

const red = (a, b)=>{
    return a*b;
}
console.log(arr4.reduce(red));



let arr5 = Array.from("Suryansh");
console.log(arr5);