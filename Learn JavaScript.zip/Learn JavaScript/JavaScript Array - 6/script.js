console.log("Hey this is JavaScript");



let arr = [1, 2, 3, 4, 5];

console.log(arr);
console.log(typeof arr);
console.log(arr.length);
console.log(arr[0]);
console.log(arr[1]);
console.log(arr[2]);
console.log(arr[3]);
console.log(arr[4]);
console.log(arr.toString());
console.log(arr.join(" And "));


let arr2 = [1, 2, 3, 4, 5];

console.log(arr2);
console.log(arr2[0] = 100);
console.log(arr2.pop());
console.log(arr2);
console.log(arr2.push("Suryansh"));
console.log(arr2);
console.log(arr2.shift());
console.log(arr2);
console.log(arr2.unshift("1"))
console.log(arr2);
console.log(delete arr2[4]);
console.log(arr2);
console.log(arr2.length);



let a1 = [1, 2, 3];
let a2 = [4, 5, 6];
let a3 = [7, 8, 9];

console.log(a1.concat(a2, a3));



let a = [7, 8, 9];

console.log(a.sort((x, y) => y - x));
console.log(a.sort((x, y) => x - y));



let number = [1, 2, 3, 4, 5];

console.log(number.splice(1, 2));
console.log(number);

console.log(number.splice(1, 2, 22, 33));
console.log(number);



let numbers = [1, 2, 3, 4, 5];

console.log(numbers.slice(2));
console.log(numbers);

console.log(numbers.slice(1, 3));
console.log(numbers);


console.log(numbers.reverse());
console.log(numbers);