console.log("Hey this is JavaScript");



let prom1 = new Promise((resolve, reject) => {
    let random = Math.random();
    if (random < 0.5) {
        reject("No Random Numbers Was Not Supporting You...");
    } else {
        setTimeout(() => {
            console.log("Yes Im Done");
            resolve("Suryansh");
        }, 3000);
    }
});

prom1.then((e) => {
    console.log(e);
}).catch((err) => {
    console.log(err);
});


let prom2 = new Promise((resolve, reject) => {
    let random = Math.random();
    if (random < 0.5) {
        reject("No Random Numbers Was Not Supporting You 2...");
    }
    setTimeout(() => {
        console.log("Yes Im Done 2");
        resolve("Suryansh 2");
    }, 3000);
});

prom2.then((e) => {
    console.log(e);
}).catch((err) => {
    console.log(err);
});

// We Can Also Use It Like This...

let prom3 = Promise.all([prom1, prom2]);
prom3.then((e) => {
    console.log(e);
}).catch(err => {
    console.log(err);
});

let prom4 = Promise.allSettled([prom1, prom2]);
prom4.then((e) => {
    console.log(e);
}).catch(err => {
    console.log(err);
});

let prom5 = Promise.race([prom1, prom2]);
prom5.then((e) => {
    console.log(e);
}).catch(err => {
    console.log(err);
});

let prom6 = Promise.any([prom1, prom2]);
prom6.then((e) => {
    console.log(e);
}).catch(err => {
    console.log(err);
});