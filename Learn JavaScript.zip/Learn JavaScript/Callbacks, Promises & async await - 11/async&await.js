console.log("Hey this is JavaScript");



// function getData() {
//     return new Promise((resolve, reject) => {
//         setTimeout(() => {
//             resolve(100);
//         }, 3000);
//     });
// }

// console.log("Loading Data");
// let data = getData();

// data.then((e) => {
//     console.log(data);

//     console.log("Processing Data");


//     console.log("Task 2");
// });


// Other Ways To Use This...


// async function getData() {
//     return new Promise((resolve, reject) => {
//         setTimeout(() => {
//             resolve(100);
//         }, 3000);
//     });
// }

// async function main() {

//     console.log("Loading Data");
//     let data = await getData();


//     console.log(data);

//     console.log("Processing Data");


//     console.log("Task 2");

// }

// main();


// How To Use In Real Projects


// async function getData() {
//     // Fake API...
//     fetch('https://jsonplaceholder.typicode.com/todos/1');
//         .then(response => response.json());
//         .then(json => console.log(json));
// }


// How To Use This In async await...


// async function getData() {
//     // Fake API...
//     let API = await fetch('https://jsonplaceholder.typicode.com/todos/1');
//     let data = await API.json();
//     console.log(data);
// }

// async function main() {

//     console.log("Loading Data");
//     let data = await getData();


//     console.log(data);

//     console.log("Processing Data");


//     console.log("Task 2");

// }

// main();


// Using A Another API...


async function getData() {
    // API...
    let data = await fetch('https://jsonplaceholder.typicode.com/posts', {
                method: 'POST',
                body: JSON.stringify({
                    title: 'foo',
                    body: 'bar',
                    userId: 1,
                }),
                headers: {
                    'Content-type': 'application/json; charset=UTF-8',
                },
            })
    let datas = await data.json() 
    return datas;
}

async function main() {

    console.log("Loading Data");
    let data = await getData();


    console.log(data);

    console.log("Processing Data");


    console.log("Task 2");

}

main();