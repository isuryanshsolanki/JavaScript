console.log("Hey this is JavaScript");


setTimeout(() => {
    console.log("Hey Im Inside SetTimeout");
}, 3000);

setTimeout(() => {
    console.log("Hey Im Inside SetTimeout 2");
}, 0);


console.log("The End");



const callback = (arg) => {
    console.log(arg);
}
const loadscript = (src, callback) => {
    let script = document.createElement("script");
    script.src = src;
    script.onload = callback("Suryansh");
    document.head.append(script);
}

loadscript("https://cdnjs.cloudflare.com/ajax/libs/prism/9000.0.1/prism.min.js", callback);