console.log("Hey this is JavaScript");



let a = prompt("Enter Frist Number");
let b = prompt("Enter Second Number");

let Sum = parseInt(a) + parseInt(b);

if (isNaN(a) || isNaN(b)) {
    throw SyntaxError("Sorry Only Numbers Is Allowed Here...");
}

// try {
//     console.log(`The Sum is ${Sum * x}`);
// } catch (error) {
//     console.log(`Error: Sorry`);
// }

// Using Finally...

function main() {
    let x = 0;
    try {
        console.log(`The Sum is ${Sum * x}`);
        return true;
    } catch (error) {
        console.log(`Error: Sorry`);
        return false;
    } finally {
        console.log("Files Are Being Closed And db Connection Is Being Closed");
    }
}

main();