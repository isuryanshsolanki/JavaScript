console.log("Hey this is javaScritp");



// let obj = {
//     "Name": "Suryansh",
//     "age": "14"
// }

// console.log(obj);



// let animal = {
//     "Eats": true
// }
// let rabbit = {
//     "Jumps": true
// }

// rabbit.__proto__ = animal; // Sets rabbit.[[Prototype]] = animal...



class Animal {
    constructor(name) {
        this.name = name;
        console.log("Object Is Created...");
    } Eats() {
        console.log("Eating");
    } Jumps() {
        console.log("Jumping");
    }
}

class Lion extends Animal {
    constructor(name) {
        super(name);
        console.log("Object Is Created And He/She Is A Lion...");
    } Eats() {
        console.log("Lion Is Eating");
    } Jumps() {
        super.Jumps();
        console.log("Lion Is Jumping");
    }
}
let a = new Animal("Animal's");
console.log(a);

let l = new Lion("Lion's");
console.log(l);

console.log(a instanceof Animal);
console.log(l instanceof Animal);
console.log(a instanceof Object);
console.log(l instanceof Object);
