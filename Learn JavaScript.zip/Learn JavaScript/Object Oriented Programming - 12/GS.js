console.log("Hey this is JavaScript");



class User {
    constructor(name) {
        this.name = name;
    }
    
    get name() {
        return this._name;
    }

    set name(value) {
        if (value.length < 4) {
            console.log("Name Is Too Short...");
            return;
        } else {
            console.log("You Enter Upper Than 4 Words Name...")
        }
        this._name = value;
    }
}

let user = new User("Suryansh");
console.log(user.name);